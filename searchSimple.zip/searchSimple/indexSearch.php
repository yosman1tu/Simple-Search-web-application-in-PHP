<?php

$conn = mysqli_connect("localhost","shoppers","password","searchBar");

if(mysqli_connect_errno()){
    echo "Failed to connect: ". mysqli_connect_error();
}
    
?>


<html>
    <head>
        <title>Search - Home</title>
        <link rel="stylesheet"
type="text/css" href="style.css"/>
        
         <script type="text/javascript" />
 function active(){
 
    var sb = document.getElementById('searchBox');
    
    if(sb.value == 'Search...'){
    sb.value = ''
    sb.placeholder = 'Search...'
    }
 }
 
  function inactive(){
 
    var sb = document.getElementById('searchBox');
    
    if(sb.value == ''){
    sb.value = 'Search...'
    sb.placeholder = ''
    }
}
 
 </script>
        
        
    </head>
<body>
    
    <form action="indexSearch.php" method="GET" id="searchForm" />
    
    <input type="text" name="q" id="searchBox" placeholder="" value="Search..." maxlength="25" autocomplete="off" onMouseDown="active();" onBlur="inactive();" /><input type="submit" id="searchBtn" value="Go!" />
    </form>


<?php

$output = '';
if(isset($_GET['q']) && $_GET['q'] !== ' '){
    $searchq = $_GET['q'];
    
    
    $q = mysqli_query($conn, "SELECT * FROM products WHERE description LIKE '%$searchq%' OR title LIKE '%$searchq%'") or die(mysqli_error());
    
    $c = mysqli_num_rows($q);
    
    if($c == 0){
        $output = 'No search results for <b>"' . $searchq .'"</b>';
        
        print("$output").'</br>';

        print ("$c  results for $searchq");  
        
    }else{
        print ("$c  results for $searchq");
        
        while($row = mysqli_fetch_array($q)){
            $id = $row['id'];
            $title = $row['title'];
            $desc = $row['description'];
            $link = $row['link'];
            
            
            $output = '<a href="' . $link .'">
            <h3>' . $title . '</h3>
                <p>' .$desc . '</p>
            </a>';
            
            
            
            print("$output");
            
        }
         

            //print ("$c  results for $searchq");
    }
    
}else{
    header("location: ./");
}



mysqli_close($conn);

?>


</body>
</html>
 